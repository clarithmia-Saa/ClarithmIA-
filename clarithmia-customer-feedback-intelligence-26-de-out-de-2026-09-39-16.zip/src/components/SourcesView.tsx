import { useEffect, useMemo, useState } from 'react';
import type { Translation } from '@/i18n';
import { Icon } from '@/components/icons';
import { ConnectSourceModal, SourcePickerModal } from '@/components/IntegrationModals';
import {
  PLATFORM_ICONS,
  platformDesc,
  platformLabel,
  statusLabel,
  type PlatformId,
  type StatusId,
} from '@/components/platforms';

export type SourceRow = {
  platform: PlatformId;
  status: StatusId;
  count: string;
  lastSync: string;
  connected: boolean;
  errorMessage?: string;
};

type ConnectTarget = { platform: PlatformId; mode: 'connect' | 'configure'; index: number | null };

const DEFAULT_SOURCES_FALLBACK: SourceRow[] = [
  { platform: 'support', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'appstore', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'playstore', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'x', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'instagram', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'tiktok', status: 'disconnected', count: '0', lastSync: '—', connected: false },
  { platform: 'youtube', status: 'disconnected', count: '0', lastSync: '—', connected: false },
];

function SourcesView({ t }: { t: Translation }) {
  const [sources, setSources] = useState<SourceRow[]>(DEFAULT_SOURCES_FALLBACK);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [target, setTarget] = useState<ConnectTarget | null>(null);
  const [syncingPlatform, setSyncingPlatform] = useState<PlatformId | null>(null);
  const [loadingInitial, setLoadingInitial] = useState(true);

  // Load live sources state from the backend API, replacing static data
  useEffect(() => {
    let isMounted = true;

    async function loadSources() {
      try {
        const res = await fetch('/api/sources');
        if (!res.ok) throw new Error('Failed to fetch sources');
        const data = await res.json();
        if (data.ok && Array.isArray(data.sources) && isMounted) {
          const mapped: SourceRow[] = data.sources.map((item: any) => ({
            platform: item.platform as PlatformId,
            status: item.status as StatusId,
            count: item.count || '0',
            lastSync: item.lastSync || '—',
            connected: Boolean(item.connected),
            errorMessage: item.errorMessage,
          }));
          setSources(mapped);
        }
      } catch {
        // Keep fallback state
      } finally {
        if (isMounted) setLoadingInitial(false);
      }
    }

    loadSources();

    return () => {
      isMounted = false;
    };
  }, []);

  const connectedCount = useMemo(() => sources.filter((s) => s.connected && s.status === 'synced').length, [sources]);
  const errorCount = useMemo(() => sources.filter((s) => s.status === 'auth_error').length, [sources]);
  const connectingCount = useMemo(() => sources.filter((s) => s.status === 'connecting').length, [sources]);

  const connectedPlatforms = useMemo(() => {
    const set = new Set<PlatformId>();
    sources.forEach((s) => {
      if (s.connected) set.add(s.platform);
    });
    return set;
  }, [sources]);

  // Disconnect a source via real backend API
  async function disconnect(index: number) {
    const source = sources[index];
    if (!source) return;

    // Optimistic UI update
    setSources((prev) =>
      prev.map((s, i) => (i === index ? { ...s, connected: false, status: 'disconnected', lastSync: '—', count: '0', errorMessage: undefined } : s)),
    );

    try {
      await fetch(`/api/connectors/${source.platform}/disconnect`, {
        method: 'POST',
      });
    } catch {
      // Handled gracefully
    }
  }

  // Trigger manual sync via real backend API
  async function syncNow(platform: PlatformId) {
    setSyncingPlatform(platform);
    setSources((prev) =>
      prev.map((s) => (s.platform === platform ? { ...s, status: 'connecting' } : s)),
    );

    try {
      const res = await fetch(`/api/connectors/${platform}/sync`, { method: 'POST' });
      const data = await res.json().catch(() => null);

      if (res.ok && data?.ok) {
        setSources((prev) =>
          prev.map((s) =>
            s.platform === platform
              ? { ...s, status: 'synced', count: data.count || s.count, lastSync: data.lastSync || 'agora', connected: true, errorMessage: undefined }
              : s,
          ),
        );
      } else {
        setSources((prev) =>
          prev.map((s) =>
            s.platform === platform
              ? { ...s, status: 'auth_error', errorMessage: data?.error || 'Erro de Autenticação ao sincronizar' }
              : s,
          ),
        );
      }
    } catch {
      setSources((prev) =>
        prev.map((s) =>
          s.platform === platform
            ? { ...s, status: 'auth_error', errorMessage: 'Erro de rede ao sincronizar' }
            : s,
        ),
      );
    } finally {
      setSyncingPlatform(null);
    }
  }

  // Real callbacks when modal submits credentials
  function handleStartConnecting(platform: PlatformId) {
    setSources((prev) => {
      const existing = prev.findIndex((s) => s.platform === platform);
      if (existing >= 0) {
        return prev.map((s, i) => (i === existing ? { ...s, status: 'connecting', errorMessage: undefined } : s));
      }
      return [...prev, { platform, status: 'connecting', count: '0', lastSync: '—', connected: false }];
    });
  }

  function handleConnected(platform: PlatformId, count?: string) {
    setSources((prev) => {
      const existing = prev.findIndex((s) => s.platform === platform);
      if (existing >= 0) {
        return prev.map((s, i) =>
          i === existing
            ? {
                ...s,
                connected: true,
                status: 'synced',
                count: count || s.count || '1.200',
                lastSync: 'agora',
                errorMessage: undefined,
              }
            : s,
        );
      }
      return [
        ...prev,
        {
          platform,
          status: 'synced',
          count: count || '1.200',
          lastSync: 'agora',
          connected: true,
          errorMessage: undefined,
        },
      ];
    });
  }

  function handleError(platform: PlatformId, errorMessage: string) {
    setSources((prev) => {
      const existing = prev.findIndex((s) => s.platform === platform);
      if (existing >= 0) {
        return prev.map((s, i) =>
          i === existing
            ? {
                ...s,
                connected: false,
                status: 'auth_error',
                errorMessage,
                lastSync: 'Falhou',
              }
            : s,
        );
      }
      return [
        ...prev,
        {
          platform,
          status: 'auth_error',
          count: '0',
          lastSync: 'Falhou',
          connected: false,
          errorMessage,
        },
      ];
    });
  }

  return (
    <div className="sources-view">
      <div className="sources-header">
        <div>
          <p className="panel-kicker"><Icon name="database" size={13} /> {t.dashboard.connectivity}</p>
          <h1 className="sources-title">{t.sources.title}</h1>
          <p className="sources-subtitle">{t.sources.subtitle}</p>
        </div>
        <button className="button button-dark sources-add" onClick={() => setPickerOpen(true)}>
          <Icon name="plus" size={16} /> {t.sources.connectNew}
        </button>
      </div>

      <div className="sources-summary">
        <div className="sources-summary-card">
          <span className="sources-summary-value">{connectedCount.toString().padStart(2, '0')}</span>
          <span className="sources-summary-label">{t.sources.connectedCount(connectedCount)}</span>
        </div>
        <div className="sources-summary-card">
          {errorCount > 0 ? (
            <>
              <span className="sources-summary-value" style={{ color: '#f87171' }}>
                {errorCount} {errorCount === 1 ? 'erro' : 'erros'}
              </span>
              <span className="sources-summary-label" style={{ color: '#fca5a5' }}>
                Atenção necessária
              </span>
            </>
          ) : connectingCount > 0 ? (
            <>
              <span className="sources-summary-value" style={{ color: '#38bdf8' }}>
                {t.sources.statusConnecting}
              </span>
              <span className="sources-summary-label">Sincronizando fontes</span>
            </>
          ) : (
            <>
              <span className="sources-summary-value operational-dot">
                {connectedCount > 0 ? t.sources.statusSynced : t.sources.statusOperational}
              </span>
              <span className="sources-summary-label">{t.dashboard.operational}</span>
            </>
          )}
        </div>
      </div>

      {loadingInitial && (
        <div style={{ padding: '20px 0', textAlign: 'center', color: '#8d949a', fontSize: '12px' }}>
          <span className="spin" style={{ display: 'inline-block', marginRight: '8px' }}>
            <Icon name="refresh" size={14} />
          </span>
          Carregando status das fontes em tempo real...
        </div>
      )}

      <div className="sources-grid">
        {sources.map((source, index) => {
          const PlatformIcon = PLATFORM_ICONS[source.platform];
          const isConnecting = source.status === 'connecting' || syncingPlatform === source.platform;
          const isAuthError = source.status === 'auth_error';
          const isSynced = source.status === 'synced' || (source.connected && source.status === 'operational');

          return (
            <article
              className={`source-card ${source.status} ${source.connected ? 'connected' : 'disconnected'}`}
              key={`${source.platform}-${index}`}
            >
              <div className="source-card-top">
                <span className={`source-platform-icon ${source.platform}`}>
                  <PlatformIcon size={22} />
                </span>

                {/* Clear visual badge states */}
                <span className={`source-status-badge ${source.status}`}>
                  {isSynced && <Icon name="checkCircle" size={11} />}
                  {isConnecting && <Icon name="refresh" size={11} className="spin" />}
                  {isAuthError && <Icon name="alert" size={11} />}
                  {source.status === 'disconnected' && <Icon name="plug" size={10} />}
                  {source.status === 'error' && <Icon name="x" size={10} />}
                  {statusLabel(t, source.status)}
                </span>
              </div>

              <h3 className="source-card-name">{platformLabel(t, source.platform)}</h3>
              <p className="source-card-desc">{platformDesc(t, source.platform)}</p>

              {/* In Authentication Error state, show clear error banner */}
              {isAuthError && source.errorMessage && (
                <div className="source-error-banner" role="alert">
                  <Icon name="alert" size={14} />
                  <span>{source.errorMessage}</span>
                </div>
              )}

              <div className="source-card-stats">
                <div>
                  <strong>{source.count}</strong>
                  <span>{t.sources.feedbacksCaptured}</span>
                </div>
                <div>
                  <strong>{source.lastSync}</strong>
                  <span>{t.sources.lastSync}</span>
                </div>
              </div>

              <div className="source-card-actions">
                {source.connected || isSynced ? (
                  <>
                    <button
                      type="button"
                      className="source-action configure"
                      onClick={() => setTarget({ platform: source.platform, mode: 'configure', index })}
                    >
                      <Icon name="settings" size={13} /> {t.sources.configure}
                    </button>
                    <button
                      type="button"
                      className="source-action sync-now"
                      disabled={isConnecting}
                      title="Sincronizar dados em tempo real"
                      onClick={() => syncNow(source.platform)}
                    >
                      <Icon name="refresh" size={13} className={isConnecting ? 'spin' : ''} />
                      {isConnecting ? t.sources.statusConnecting : t.sources.syncNow}
                    </button>
                    <button
                      type="button"
                      className="source-action disconnect"
                      onClick={() => disconnect(index)}
                    >
                      {t.sources.disconnect}
                    </button>
                  </>
                ) : isAuthError ? (
                  <>
                    <button
                      type="button"
                      className="source-action reconnect"
                      onClick={() => setTarget({ platform: source.platform, mode: 'configure', index })}
                    >
                      <Icon name="rotate" size={13} /> {t.sources.reconnect}
                    </button>
                    <button
                      type="button"
                      className="source-action disconnect"
                      onClick={() => disconnect(index)}
                    >
                      {t.sources.disconnect}
                    </button>
                  </>
                ) : isConnecting ? (
                  <button type="button" className="source-action connect" disabled>
                    <Icon name="refresh" size={13} className="spin" /> {t.sources.statusConnecting}
                  </button>
                ) : (
                  <button
                    type="button"
                    className="source-action connect"
                    onClick={() => setTarget({ platform: source.platform, mode: 'connect', index })}
                  >
                    <Icon name="plugZap" size={13} /> {t.sources.connect}
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {pickerOpen && (
        <SourcePickerModal
          t={t}
          connected={connectedPlatforms}
          onClose={() => setPickerOpen(false)}
          onSelect={(platform) => {
            setPickerOpen(false);
            setTarget({ platform, mode: 'connect', index: null });
          }}
        />
      )}

      {target && (
        <ConnectSourceModal
          key={`${target.platform}-${target.mode}-${target.index}`}
          t={t}
          platform={target.platform}
          mode={target.mode}
          onClose={() => setTarget(null)}
          onStartConnecting={handleStartConnecting}
          onConnected={handleConnected}
          onError={handleError}
        />
      )}
    </div>
  );
}

export default SourcesView;
